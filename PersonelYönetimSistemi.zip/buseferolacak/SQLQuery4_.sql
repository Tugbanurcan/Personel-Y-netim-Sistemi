SELECT departman_id, departman_ad� 
FROM Departman 
WHERE departman_ad� LIKE '%A%';
