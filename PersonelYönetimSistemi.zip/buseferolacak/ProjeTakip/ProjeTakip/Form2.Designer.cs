﻿namespace ProjeTakip
{
    partial class TabloSayfaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TabloSayfaForm));
            this.buttonTablo1 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.buttonDepartman = new Bunifu.Framework.UI.BunifuThinButton2();
            this.buttonProje = new Bunifu.Framework.UI.BunifuThinButton2();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSanal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.SuspendLayout();
            // 
            // buttonTablo1
            // 
            this.buttonTablo1.ActiveBorderThickness = 1;
            this.buttonTablo1.ActiveCornerRadius = 20;
            this.buttonTablo1.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.buttonTablo1.ActiveForecolor = System.Drawing.Color.White;
            this.buttonTablo1.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.buttonTablo1.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTablo1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonTablo1.BackgroundImage")));
            this.buttonTablo1.ButtonText = "Personel Bilgileri";
            this.buttonTablo1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTablo1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTablo1.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonTablo1.IdleBorderThickness = 1;
            this.buttonTablo1.IdleCornerRadius = 20;
            this.buttonTablo1.IdleFillColor = System.Drawing.Color.White;
            this.buttonTablo1.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.buttonTablo1.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.buttonTablo1.Location = new System.Drawing.Point(85, 93);
            this.buttonTablo1.Margin = new System.Windows.Forms.Padding(5);
            this.buttonTablo1.Name = "buttonTablo1";
            this.buttonTablo1.Size = new System.Drawing.Size(181, 194);
            this.buttonTablo1.TabIndex = 0;
            this.buttonTablo1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.buttonTablo1.Click += new System.EventHandler(this.buttonTablo1_Click);
            // 
            // buttonDepartman
            // 
            this.buttonDepartman.ActiveBorderThickness = 1;
            this.buttonDepartman.ActiveCornerRadius = 20;
            this.buttonDepartman.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.buttonDepartman.ActiveForecolor = System.Drawing.Color.White;
            this.buttonDepartman.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.buttonDepartman.BackColor = System.Drawing.SystemColors.Control;
            this.buttonDepartman.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonDepartman.BackgroundImage")));
            this.buttonDepartman.ButtonText = "Departman Bilgileri";
            this.buttonDepartman.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDepartman.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDepartman.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonDepartman.IdleBorderThickness = 1;
            this.buttonDepartman.IdleCornerRadius = 20;
            this.buttonDepartman.IdleFillColor = System.Drawing.Color.White;
            this.buttonDepartman.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.buttonDepartman.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.buttonDepartman.Location = new System.Drawing.Point(296, 93);
            this.buttonDepartman.Margin = new System.Windows.Forms.Padding(5);
            this.buttonDepartman.Name = "buttonDepartman";
            this.buttonDepartman.Size = new System.Drawing.Size(181, 194);
            this.buttonDepartman.TabIndex = 0;
            this.buttonDepartman.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.buttonDepartman.Click += new System.EventHandler(this.buttonDepartman_Click);
            // 
            // buttonProje
            // 
            this.buttonProje.ActiveBorderThickness = 1;
            this.buttonProje.ActiveCornerRadius = 20;
            this.buttonProje.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.buttonProje.ActiveForecolor = System.Drawing.Color.White;
            this.buttonProje.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.buttonProje.BackColor = System.Drawing.SystemColors.Control;
            this.buttonProje.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonProje.BackgroundImage")));
            this.buttonProje.ButtonText = "Proje Bilgileri";
            this.buttonProje.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonProje.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProje.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonProje.IdleBorderThickness = 1;
            this.buttonProje.IdleCornerRadius = 20;
            this.buttonProje.IdleFillColor = System.Drawing.Color.White;
            this.buttonProje.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.buttonProje.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.buttonProje.Location = new System.Drawing.Point(519, 93);
            this.buttonProje.Margin = new System.Windows.Forms.Padding(5);
            this.buttonProje.Name = "buttonProje";
            this.buttonProje.Size = new System.Drawing.Size(181, 194);
            this.buttonProje.TabIndex = 0;
            this.buttonProje.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.buttonProje.Click += new System.EventHandler(this.buttonProje_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Variable Small", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(412, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 33);
            this.label1.TabIndex = 4;
            this.label1.Text = "Verileri Yönet";
            // 
            // buttonSanal
            // 
            this.buttonSanal.ActiveBorderThickness = 1;
            this.buttonSanal.ActiveCornerRadius = 20;
            this.buttonSanal.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.buttonSanal.ActiveForecolor = System.Drawing.Color.White;
            this.buttonSanal.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.buttonSanal.BackColor = System.Drawing.SystemColors.Control;
            this.buttonSanal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonSanal.BackgroundImage")));
            this.buttonSanal.ButtonText = "Sanal Tablo Bilgileri";
            this.buttonSanal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSanal.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSanal.ForeColor = System.Drawing.Color.SeaGreen;
            this.buttonSanal.IdleBorderThickness = 1;
            this.buttonSanal.IdleCornerRadius = 20;
            this.buttonSanal.IdleFillColor = System.Drawing.Color.White;
            this.buttonSanal.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.buttonSanal.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.buttonSanal.Location = new System.Drawing.Point(740, 93);
            this.buttonSanal.Margin = new System.Windows.Forms.Padding(5);
            this.buttonSanal.Name = "buttonSanal";
            this.buttonSanal.Size = new System.Drawing.Size(181, 194);
            this.buttonSanal.TabIndex = 5;
            this.buttonSanal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.buttonSanal.Click += new System.EventHandler(this.buttonSanal_Click);
            // 
            // TabloSayfaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 376);
            this.Controls.Add(this.buttonSanal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonProje);
            this.Controls.Add(this.buttonDepartman);
            this.Controls.Add(this.buttonTablo1);
            this.Name = "TabloSayfaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tablolar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 buttonTablo1;
        private Bunifu.Framework.UI.BunifuThinButton2 buttonDepartman;
        private Bunifu.Framework.UI.BunifuThinButton2 buttonProje;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuThinButton2 buttonSanal;
    }
}