CREATE TABLE Departman (
    departman_id INT PRIMARY KEY IDENTITY(1,1),
    departman_ad� NVARCHAR(50)
);