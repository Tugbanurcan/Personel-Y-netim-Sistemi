CREATE PROCEDURE AddDepartman
    @departmanAdi NVARCHAR(50)
AS
BEGIN
    INSERT INTO Departman (departman_ad�)
    VALUES (@departmanAdi)
END
